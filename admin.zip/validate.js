function validateUser() {
    event.preventDefault();  // Prevent form submission


    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    // Set your valid username and password
    var validUsername = "root";
    var validPassword = "root";

    // Check if the entered username and password match
    if (username === validUsername && password === validPassword) {
        alert("Welcome to AdminPage");
        // Redirect to another page upon successful login
        window.location.href = "view.php";  // Replace with the desired page
    } else {
        alert("Invalid username or password.");
    }
}